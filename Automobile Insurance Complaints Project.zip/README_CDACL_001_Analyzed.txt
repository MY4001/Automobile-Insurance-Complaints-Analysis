CDACL-001 analyzed project deliverables

Files:
- CDACL_001_Project_Report_Analyzed.docx: data-driven findings, caveats, dashboard plan.
- CDACL_001_Project_Presentation_Analyzed.pptx: presentation with findings and charts.
- CDACL_001_Analyzed_Data.xlsx: raw data, analysis copy, annual summary, five-company comparison, data quality.
- CDACL_001_SQL_Starter.sql: adaptable SQL queries (table/column names may need mapping).
- Four PNG charts: complaint outcomes, premium trend, five-company ratio, premiums vs upheld complaints.

Important data quality flags:
1) 2015 and 2016 rows match exactly across all available data fields.
2) Maidstone Insurance Company has two 2014 rows with conflicting values.
3) FIELD11 and FIELD12 are entirely blank.
4) Ratio is highly right-skewed and the CSV does not specify the scale; validate before interpreting as a percentage.
