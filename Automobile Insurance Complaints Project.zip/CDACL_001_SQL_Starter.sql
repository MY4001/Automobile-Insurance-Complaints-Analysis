/*
CDACL-001 | Automobile Insurance Complaints
SQL starter script for MySQL / MariaDB.

IMPORTANT:
1) The assignment brief names the database project_automobile_insurance and
   the account dm_team14, but does not specify the table or column names.
2) Run SHOW TABLES and DESCRIBE <table_name>; then replace the placeholders
   below with the real table/column names.
3) Never commit credentials into a public repository or presentation.
*/

USE project_automobile_insurance;

SHOW TABLES;

-- After identifying the table:
-- DESCRIBE your_table_name;
-- SELECT * FROM your_table_name LIMIT 10;

-- Suggested normalized analysis fields:
-- Company Name, Filling Year, Upheld Complaints, Question of Fact Complaints,
-- Not Upheld Complaints, Total Complaints, Premiums Written (in Millions),
-- Ratio, Rank, NAIC.

-- 1. Annual complaint trend by year
SELECT
    `Filling Year` AS filing_year,
    SUM(`Upheld Complaints`) AS upheld_complaints,
    SUM(`Question of Fact Complaints`) AS question_of_fact_complaints,
    SUM(`Not Upheld Complaints`) AS not_upheld_complaints,
    SUM(`Total Complaints`) AS total_complaints
FROM your_table_name
GROUP BY `Filling Year`
ORDER BY filing_year;

-- 2. Company complaint mix across the available period
SELECT
    `Company Name` AS company_name,
    SUM(`Upheld Complaints`) AS upheld_complaints,
    SUM(`Question of Fact Complaints`) AS question_of_fact_complaints,
    SUM(`Not Upheld Complaints`) AS not_upheld_complaints,
    SUM(`Total Complaints`) AS total_complaints
FROM your_table_name
GROUP BY `Company Name`
ORDER BY upheld_complaints DESC;

-- 3. Premium trend by year (confirm the meaning of the premium field first)
SELECT
    `Filling Year` AS filing_year,
    AVG(`Premiums Written (in Millions)`) AS avg_premiums_written_millions
FROM your_table_name
GROUP BY `Filling Year`
ORDER BY filing_year;

-- 4. Five-company comparison for dashboard (replace with selected companies)
SELECT
    `Company Name` AS company_name,
    `Filling Year` AS filing_year,
    SUM(`Upheld Complaints`) AS upheld_complaints,
    SUM(`Total Complaints`) AS total_complaints,
    AVG(`Ratio`) AS avg_complaint_ratio,
    AVG(`Premiums Written (in Millions)`) AS avg_premiums_written_millions,
    AVG(`Rank`) AS avg_rank
FROM your_table_name
WHERE `Company Name` IN ('Company A', 'Company B', 'Company C', 'Company D', 'Company E')
GROUP BY `Company Name`, `Filling Year`
ORDER BY filing_year, company_name;

-- 5. Data quality check: complaint total reconciliation
SELECT *
FROM your_table_name
WHERE COALESCE(`Total Complaints`, 0) <>
      COALESCE(`Upheld Complaints`, 0)
    + COALESCE(`Question of Fact Complaints`, 0)
    + COALESCE(`Not Upheld Complaints`, 0);

-- 6. Potential duplicate rows (inspect before deleting anything)
SELECT
    `NAIC`, `Company Name`, `Filling Year`, COUNT(*) AS row_count
FROM your_table_name
GROUP BY `NAIC`, `Company Name`, `Filling Year`
HAVING COUNT(*) > 1;

-- 7. Check missing / invalid values
SELECT
    SUM(`Company Name` IS NULL OR TRIM(`Company Name`) = '') AS missing_company,
    SUM(`Filling Year` IS NULL) AS missing_year,
    SUM(`Premiums Written (in Millions)` IS NULL) AS missing_premium,
    SUM(`Upheld Complaints` IS NULL) AS missing_upheld,
    SUM(`Total Complaints` IS NULL) AS missing_total
FROM your_table_name;

-- Do not compare raw complaint counts alone across companies of very different
-- sizes. The brief defines Ratio as upheld complaints divided by average
-- current/prior-year premiums written. Validate units and ratio scale before
-- interpreting or charting it.
